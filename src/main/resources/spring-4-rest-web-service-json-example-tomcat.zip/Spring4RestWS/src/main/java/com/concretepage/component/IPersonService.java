package com.concretepage.component;

import com.concretepage.Person;

public interface IPersonService {
  public Person getPersonDetail(Integer id);
}
